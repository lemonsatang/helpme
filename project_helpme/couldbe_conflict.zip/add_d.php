<?php 

	include 'database.php';

	$pdcod = $_POST['PDCOD'];
	$id = $_POST['ID'];
	$seq = $_POST['SEQ'];
	$comp = $_POST['COMP'];
	$c_code = $_POST['C_CODE'];
	$pdnm = $_POST['PDNM'];
	$maker = $_POST['MAKER'];
	$jaejil = $_POST['JAEJIL'];
	$size = $_POST['SIZE'];
	$choolgo = $_POST['CHOOLGO'];
	$sryang = $_POST['SRYANG'];
	$unit = $_POST['UNIT'];
	$u_jryang = $_POST['U_JRYANG'];
	$jryang = $_POST['JRYANG'];
	$bigo = $_POST['BIGO'];
	$cdate = date("Y-m-d", time());
	$mdate = date("Y-m-d", time());
	$cuser = $_POST['CUSER'];
	$muser = $_POST['MUSER'];

	$link->query("INSERT INTO crt_dft_d(PDCOD,ID,SEQ,COMP,C_CODE,PDNM,MAKER,JAEJIL,SIZE,CHOOLGO,SRYANG,UNIT,BIGO,CUSER,MUSER)
	VALUES('".$pdcod."','".$id."','".$seq."','".$comp."','".$c_code."','".$pdnm."','".$maker."','".$jaejil."','".$size."','".$choolgo."','".$sryang."','".$unit."','".$u_jryang."','".$jryang."','".$bigo."','".$cdata."','".$mdate."','".$cuser."','".$muser."')");